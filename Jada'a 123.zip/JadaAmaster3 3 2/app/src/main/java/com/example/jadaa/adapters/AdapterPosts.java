package com.example.jadaa.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.jadaa.R;
import com.example.jadaa.models.ModelPost;
import com.squareup.picasso.Picasso;

import java.net.URI;
import java.util.List;

public class AdapterPosts extends RecyclerView.Adapter<AdapterPosts.MyHolder>{

   // String uid,pTitle,pDescription,pAuthor,pEdition,pImage,pPrice,pStatus,pCollege,pDate,pTime,pPublisher;
    Context context;
    List<ModelPost> postList;

    public AdapterPosts(Context context, List<ModelPost> postList) {
        this.context = context;
        this.postList = postList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        //inflate layout row_posts.xml
        View view = LayoutInflater.from(context).inflate(R.layout.row_posts,viewGroup,false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder myHolder, int i) {
         //get data
        String uid = postList.get(i).getUid();
        String pTitle = postList.get(i).getBookTitle();
        String pDescription = postList.get(i).getBookDescription();
        String pAuthor = postList.get(i).getBookAuthor();
        String pEdition = postList.get(i).getBookEdition();
       String pImage = (postList.get(i).getBookImage());
        String pPrice = postList.get(i).getBookPrice();
        String pStatus = postList.get(i).getBookStatus();
        String pCollege = postList.get(i).getCollege();
        String pDate = postList.get(i).getPostDate();
        String pTime = postList.get(i).getPostTime();
        String pPublisher = postList.get(i).getPublisher();
        //set data
        myHolder.uNameTv.setText(pPublisher);
        myHolder.pTimeTv.setText(pDate+" "+pTime);
        myHolder.pTitle.setText(pTitle);
        myHolder.pDescriptionTv.setText(pDescription);
       //  myHolder.pImageIv.setImageURI(Uri.parse(pImage));

        //set post image
        //String url = pImage;



        try{


            //  Picasso.get().load(pImage).into(myHolder.pImageIv);
            Picasso.get().load(postList.get(i).getBookImage()).into(myHolder.pImageIv);
           // myHolder.pImageIv.setImageURI(Uri.parse(pImage));
        }
        catch (Exception e){
        }

    }

    @Override
    public int getItemCount() {
        return postList.size();
    }


    //view holder class
    class MyHolder extends RecyclerView.ViewHolder{

        //views from row_posts.xml
        ImageView uPictureIv, pImageIv;
        TextView uNameTv, pTimeTv, pTitle, pDescriptionTv;
        ImageButton moreBtn;
        Button favoriteBtn, commentBtn, shareBtn;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            //init views
            uPictureIv = itemView.findViewById(R.id.uPictureIv);
            pImageIv = itemView.findViewById(R.id.pImageIv);
            uNameTv = itemView.findViewById(R.id.uNameTv);
            pTimeTv = itemView.findViewById(R.id.pTimeTv);
            pTitle = itemView.findViewById(R.id.pTitle);
            pDescriptionTv = itemView.findViewById(R.id.pDescriptionTv);
            moreBtn = itemView.findViewById(R.id.moreBtn);
            favoriteBtn = itemView.findViewById(R.id.favoriteBtn);
            commentBtn = itemView.findViewById(R.id.commentBtn);
            shareBtn = itemView.findViewById(R.id.shareBtn);



        }
    }
}//adapter class
